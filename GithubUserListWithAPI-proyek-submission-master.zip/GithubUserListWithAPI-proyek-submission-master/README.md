# GithubUserListWithAPI-proyek-submission
Aplikasi untuk Proyek Submission Modul Fundamental Android di Dicoding. Aplikasi ini untuk menampilkan Daftar User, Search User, Detail User, Daftar Followers/Following User, Add &amp; Delete User to Favorite List, Daftar Favorite dengan menggunakan GitHub API, retrofit2, room, dagger hilt serta menggunakan mockito dan expresso untuk testing.
